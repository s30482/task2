import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        double cena = 40.0;
        int age = customerAge();
        String city = customerCity();
        String dzien = customerDzien();
        calculating(cena, city, dzien, age);
    }
    public static Integer customerAge() {
        Scanner mySc = new Scanner(System.in);
        System.out.println("Witamy w museum. Prosimy o podanie nastepujacych danych: wiek");
        String age = mySc.nextLine();
        int ageInt = Integer.parseInt(age);
        return ageInt;
    }

    public static String customerCity() {
        Scanner mySc = new Scanner(System.in);
        System.out.println("Miejsce zamieszkania");
        String city = mySc.nextLine();
        return city;
    }

    public static String customerDzien(){
        Scanner mySc = new Scanner(System.in);
        System.out.println("Dzien Tygodnia");
        String dzien = mySc.nextLine();
        return dzien;
    }
    public static void calculating(double cena, String city,String dzien, int ageInt){
        if (city.equals("Warszawa")) {
            cena -= cena * 0.1;
        }
        if (dzien.equals("Czwartek")) {
            cena = cena * 0;
        } else if (ageInt < 10) {
            cena = cena * 0;
        } else if (ageInt > 10 && ageInt < 18) {
            cena = cena * 0.5;
        }
        System.out.println(city + ", wiek: " + ageInt + ", cena bileta: " + cena);
    }
}